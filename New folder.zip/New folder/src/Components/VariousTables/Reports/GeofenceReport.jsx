import React from 'react'

const GeofenceReport = () => {
  return (
    <div>GeofenceReport</div>
  )
}

export default GeofenceReport