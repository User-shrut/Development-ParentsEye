import React from 'react'

const StatusReport = () => {
  return (
    <div>StatusReport</div>
  )
}

export default StatusReport