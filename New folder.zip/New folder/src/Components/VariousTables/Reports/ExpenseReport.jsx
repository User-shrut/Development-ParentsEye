import React from 'react'

const ExpenseReport = () => {
  return (
    <div>ExpenseReport</div>
  )
}

export default ExpenseReport