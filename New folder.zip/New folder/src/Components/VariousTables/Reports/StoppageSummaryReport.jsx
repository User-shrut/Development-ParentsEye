import React from 'react'

const StoppageSummaryReport = () => {
  return (
    <div>StoppageSummaryReport</div>
  )
}

export default StoppageSummaryReport