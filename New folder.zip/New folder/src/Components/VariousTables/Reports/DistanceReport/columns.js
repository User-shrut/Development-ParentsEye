export const COLUMNS = [
    {
      Header: 'Vehicle',
      accessor: '',
    },
    {
      Header: '14/06/2024',
      accessor: ''
    },
    {
      Header: 'Total Distance',
      accessor: ''
    }
  ];
  