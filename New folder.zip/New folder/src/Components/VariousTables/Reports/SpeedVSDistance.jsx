import React from 'react'

const SpeedVSDistance = () => {
  return (
    <div>SpeedVSDistance</div>
  )
}

export default SpeedVSDistance