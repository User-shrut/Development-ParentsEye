import React from 'react'

const PacketReport = () => {
  return (
    <div>PacketReport</div>
  )
}

export default PacketReport