import React from 'react'

const RideReport = () => {
  return (
    <div>RideReport</div>
  )
}

export default RideReport