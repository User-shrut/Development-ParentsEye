import React from 'react'

const SensorReport = () => {
  return (
    <div>SensorReport</div>
  )
}

export default SensorReport