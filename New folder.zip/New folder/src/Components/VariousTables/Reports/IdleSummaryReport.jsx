import React from 'react'

const IdleSummaryReport = () => {
  return (
    <div>IdleSummaryReport</div>
  )
}

export default IdleSummaryReport