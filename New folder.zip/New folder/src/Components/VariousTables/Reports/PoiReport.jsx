import React from 'react'

const PoiReport = () => {
  return (
    <div>PoiReport</div>
  )
}

export default PoiReport