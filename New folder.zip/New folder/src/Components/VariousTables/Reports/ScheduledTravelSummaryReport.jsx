import React from 'react'

const ScheduledTravelSummaryReport = () => {
  return (
    <div>ScheduledTravelSummaryReport</div>
  )
}

export default ScheduledTravelSummaryReport