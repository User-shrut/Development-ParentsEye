export const COLUMNS = [
    {
      Header: 'Vehicle',
      accessor: 'vehicle',
    },
    {
      Header: 'Stoppage Duration',
      accessor: 'stoppage_duration'
    },
    {
      Header: 'Address',
      accessor: 'address'
    }
]